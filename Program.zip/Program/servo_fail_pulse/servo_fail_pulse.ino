#include <Servo.h>

const int SERVO_PIN = 8;
const int FAIL_ANGLE = 90;
const int PASS_ANGLE = 0;
const unsigned long FAIL_PULSE_MS = 1000;

Servo myservo;
String cmdBuffer = "";

void setup() {
  Serial.begin(9600);
  myservo.attach(SERVO_PIN);
  myservo.write(PASS_ANGLE);
  delay(200);
  Serial.println("READY");
}

void loop() {
  while (Serial.available() > 0) {
    int ri = Serial.read();
    char c = (char)ri;
    Serial.print("RX:");
    Serial.println(ri); // debug: show byte value

    if (c == '\n' || c == '\r') {
      // show what's in buffer before trimming/handling
      Serial.print("BUF_BEFORE:'");
      Serial.print(cmdBuffer);
      Serial.println("'");

      cmdBuffer.trim();
      Serial.print("BUF_AFTER:'");
      Serial.print(cmdBuffer);
      Serial.print("' LEN=");
      Serial.println(cmdBuffer.length());

      if (cmdBuffer.length() > 0) {
        Serial.print("CMDRECV:");
        Serial.println(cmdBuffer);
        // Debug: confirm action for known commands before calling handler
        if (cmdBuffer == "FAIL" || cmdBuffer == "fail") {
          Serial.println("DEBUG: about to execute FAIL branch");
        } else if (cmdBuffer == "PASS" || cmdBuffer == "pass") {
          Serial.println("DEBUG: about to execute PASS branch");
        }
        handleCommand(cmdBuffer);
        cmdBuffer = "";
      }
    } else {
      cmdBuffer += c;
    }
  }
}

void handleCommand(String cmd) {
  // convert to all-caps in-place (use correct API)
  cmd.toUpperCase(); // if your core has toUpperCase() name, try that; we'll compare case-insensitive below

  if (cmd == "FAIL") {
    Serial.println("ACK:FAIL");
    Serial.println("DEBUG: moving servo to FAIL_ANGLE");
    myservo.write(FAIL_ANGLE);
    delay(FAIL_PULSE_MS);
    myservo.write(PASS_ANGLE);
    Serial.println("ACK:RETURN");
  } else if (cmd == "PASS" || cmd == "OK" || cmd == "RESET") {
    myservo.write(PASS_ANGLE);
    Serial.println("ACK:PASS");
  } else {
    Serial.print("UNKNOWN:");
    Serial.println(cmd);
  }
}